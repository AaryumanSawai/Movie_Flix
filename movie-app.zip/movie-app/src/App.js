
import MovieList from './MovieList.js'

function App() {
  
  return (
    <div className="App">
      <h1>Movie App</h1>
      <MovieList/>
    </div>
  );
}

export default App;
